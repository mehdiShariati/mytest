import { Component } from '@angular/core';

@Component({
  selector: 'app-chat-channel-modal',
  templateUrl: './chat-channel-modal.component.html',
  styleUrls: ['./chat-channel-modal.component.scss'],
})
export class ChatChannelModalComponent {}
