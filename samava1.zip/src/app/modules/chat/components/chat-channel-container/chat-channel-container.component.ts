import { Component } from '@angular/core';

@Component({
  selector: 'app-chat-channel-container',
  templateUrl: './chat-channel-container.component.html',
  styleUrls: ['./chat-channel-container.component.scss'],
})
export class ChatChannelContainerComponent {}
