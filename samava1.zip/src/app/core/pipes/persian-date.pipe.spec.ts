import { PersianDatePipe } from './persian-date.pipe';

describe('PersianDatePipe', () => {
  it('create an instance', () => {
    const pipe = new PersianDatePipe();
    expect(pipe).toBeTruthy();
  });
});
