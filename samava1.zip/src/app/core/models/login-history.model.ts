export interface loginHistory {
  platform: string;
  date: string;
  time: string;
}
