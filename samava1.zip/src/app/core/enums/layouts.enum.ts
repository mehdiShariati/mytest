export enum Layouts {
  Main,
  Auth,
  Admin,
}
