export const environment = {
  production: true,
  apiUrl: 'http://172.31.112.51:8081/api/v1',
  apiUrlPublic: 'http://172.31.112.51:8081/public/v1',
  clientUser: 'client',
  clientPassword: '111',
};
