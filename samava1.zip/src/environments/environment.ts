export const environment = {
  production: false,
  apiUrl: 'http://172.31.112.51:8081/api/v1',
  apiToken: 'http://172.31.112.51:8081',
  apiUrlPublic: 'http://172.31.112.51:8081/public/v1',
  wsUrl: 'ws://172.31.112.51:8081/public/chat/ws',
  clientUser: 'client',
  clientPassword: '111',
};
